###
### SOMENTE O VALOR DO CAMPO pastaFirefoxInstalado PODE SER ALTERADO, OS DEMAIS SÃO SALVOS NO
### MOMENTO DA GERAÇÃO DO REPORT
### BY FELIPE KIMIO NISHIKAKU
###

                                                                                                              
                                                   `--`                                                       
                                           `.-/++ooyyyyo+/:-.`                                                
                                       .:+sssyyyyyyyyyyyyyyssyso/:.                                           
                                   `-+ssyyyyyyyyyyyyyyyyyyyyyyyyyyyso:`                                       
                                `:ossyyyyyyyyyyyyyyyyyyyyyyyyyyyyyhhhhyo-                                     
                              `.yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyhhhhhhhs-                                   
                            .` -yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyhhhhhhhdhs-                                 
                           -   /yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyhhhhhhhdhhh+                                
                          ``   oyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyhy/::+shhhhh`                               
                          .`   yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyhs-`   `:ohh:                               
                          -   .yyyyyyyyyyyyyyyyyhhhhhhhhhhhhhhhhhhhhso/.    .so                               
                          -   -yyyyyyyyyyyyhhyyysssoo++oooossssyyyhdhhhys+:` :y                               
                          -   :yyyyyyyysso+/::::-------------------::/osyhhy+/h                               
                          .   :yyyyss+/yds/+-...............-///-..-:...-:oyhhh`                              
                         `.  `:yys//:-hMMo:dy............../h:/Nm/..:-.....-+hh`                              
                         .`./sso:--:..oNMMMN+..............yNosMMh...:-......:+`                              
                        `/oyh+--.-/::-.:+o+:....--.........:hmNmh:....:.......:-                              
                      ./syhh/ -..+ssss-.........--...........-:-.......:......-:                              
                    .+syhhhh`.-..syyyy/.....--------.-.......:/++/:.....:-.....--                             
                  .+yyhhhhhh/:...osyyo-......-.....---......+syyyys+....:.-.....-.                            
                `/yyhhhhhhhhhdo-.-/::-......................syyyyyys....- .--....:                            
               -syhhhhhhhhhhhNMh/-:-........................:ssyyss:....- `.odhyyd:                           
              :syhhhhhhhhhhhhMMMNh-`.-.......................-://:-...../--..+mMMMy                           
              syhhhhhhhhhhhhhNMMMdyo/::-................................/-..--:yNMm`                          
              +yhhhhhhhhhhhhhNMMdhhhhhs-................................+::---../dM:-.``                      
              `+yhhhhhhhhhhhhdNdhhhhhh:..........--------...............+:::::::-:o:..---..``                 
                -oyhhhhhhhhhhhhhhhhhhy...........--:::::-..:...........-+::::::::::::---...---..``            
                  ./syhhhhhhhhhhhhhhh+..........--..---...-:..........-:+::::::::::::::::----...----..``      
                     ..-:/++oooossssy-...........:.......-:...........-://::::::::::::::::::::----....-.      
                                    :-...........-:......:...........-::/-/::::::::::::::::::::::::----       
                                   `:--...........:.....:-..........-::::-/::::/:::::::::::::::::::::-        
                                   --./-..........:....-:..........-::/:::.::::/```-::::::::::::::::-         
                                   :..:/..........:-...:..........-://:::/`/::::-    `.-:::::::::::.          
                                  .-...-:.........--...:.........-:/:::::/-::::::        `.-::::::.           
                                  -.....-:........:-...:.........:/:::::::+/::::/            .-::`            
                                 `:......-:-......:....:.......-::--::::::+:::::/                             
                                 -.........:------:....::---.-:-....-:::::/..-:::.                            
                                 :..........-::::-........----......-:::::::    `                             
                                --..................................-::::::/                                  
                                ::--...............------...........:::::::/`                                 
                                `/::::---------::::::::::::::------::::::::-                                  
                                 .::::::::::::::::::::::::::::::::::::::::-                                   
                                  .::::::::::::::::::::::::::::::::::::::.                                    
                                    :////::://:::-------:::::::::::::/:.                                      
                                 `-::::::::/-`             ``.://///::::-`                                    
                               `:/::::::::-`                   `-:::::::::-`                                  
                               ////:::-.`                         .-::::////                                  
                               .--..`                                `.-:://`                                 
                                                                                                              

                                                                                                              